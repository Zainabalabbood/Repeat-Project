//
//  ToDoTableViewController.swift
//  ToDoList2
//
//  Created by BP-36-213-09 on 06/02/2025.
//

import UIKit
import MessageUI

class ToDoTableViewController: UITableViewController, ToDoCellDelegate, UISearchBarDelegate {
    
    var todos = [ToDo]()
    var filteredTodos = [ToDo]()
    var isSearching = false
    let searchBar = UISearchBar()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.leftBarButtonItem = editButtonItem
        
        // Setup the search bar
        searchBar.delegate = self
        searchBar.placeholder = "Search"
        navigationItem.titleView = searchBar
        
        if let savedToDos = ToDo.loadToDos() {
            todos = savedToDos
        } else {
            todos = ToDo.loadSampleToDos()
        }
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            isSearching = false
            filteredTodos.removeAll()
        } else {
            isSearching = true
            filteredTodos = todos.filter { $0.title.lowercased().contains(searchText.lowercased()) }
        }
        tableView.reloadData()
    }
    
    
    @IBAction func unwindToToDoList(segue: UIStoryboardSegue) {
        guard segue.identifier == "saveUnwind" else { return }
        let sourceViewController = segue.source as! ToDoDetailTableViewController

        if let todo = sourceViewController.todo {
            if let indexOfExistingToDo = todos.firstIndex(of: todo) {
                todos[indexOfExistingToDo] = todo
                tableView.reloadRows(at: [IndexPath(row: indexOfExistingToDo, section: 0)], with: .automatic)
            } else {
                let newIndexPath = IndexPath(row: todos.count, section: 0)
                todos.append(todo)
                tableView.insertRows(at: [newIndexPath], with: .automatic)
            }
        }
        
        ToDo.saveToDos(todos)
    }
    
    @IBSegueAction func editToDo(_ coder: NSCoder, sender: Any?) -> ToDoDetailTableViewController? {
        guard let cell = sender as? UITableViewCell, let indexPath = tableView.indexPath(for: cell) else {
            return nil
        }
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        let detailController = ToDoDetailTableViewController(coder: coder)
        detailController?.todo = todos[indexPath.row]
        
        return detailController
    }
    

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isSearching ? filteredTodos.count : todos.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ToDoCellIdentifier", for: indexPath) as! ToDoCell
        
        let todo = isSearching ? filteredTodos[indexPath.row] : todos[indexPath.row]
        cell.titleLabel?.text = todo.title
        cell.isCompleteButton.isSelected = todo.isComplete
        cell.delegate = self
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            if isSearching {
                // Remove from filtered array
                let todoToRemove = filteredTodos[indexPath.row]
                if let index = todos.firstIndex(of: todoToRemove) {
                    todos.remove(at: index)
                }
                filteredTodos.remove(at: indexPath.row)
            } else {
                todos.remove(at: indexPath.row)
            }
            tableView.deleteRows(at: [indexPath], with: .automatic)
            ToDo.saveToDos(todos)
        }
    }
    
    func checkmarkTapped(sender: ToDoCell) {
        if let indexPath = tableView.indexPath(for: sender) {
            var todo = isSearching ? filteredTodos[indexPath.row] : todos[indexPath.row]
            todo.isComplete.toggle()
            if isSearching {
                filteredTodos[indexPath.row] = todo
            } else {
                todos[indexPath.row] = todo
            }
            tableView.reloadRows(at: [indexPath], with: .automatic)
            ToDo.saveToDos(todos)
        }
    }
    
    @IBAction func sharePressed(_ sender: Any) {

    // Combine all to-dos into a single string
    let toDoListString = todos.map { todo in
    """
    (todo.title)
    - Completed: (todo.isComplete ? "Yes" : "No")
    - Due: (ToDo.dueDateFormatter.string(from: todo.dueDate))
    (todo.notes ?? "")
    """
    }.joined(separator: "\n\n")

    // Create the text to share
    let textToShare = "Here's my to-do list:\n\n(toDoListString)"

    // Initialize the activity view controller
    let activityViewController = UIActivityViewController(activityItems: [textToShare], applicationActivities: nil)

    // Remove excluded activity types to ensure the Mail app is included
    activityViewController.excludedActivityTypes = [
    .postToFacebook,
    .postToTwitter,
    .postToWeibo
    ] // Exclude irrelevant ones only if needed

    // Present the activity view controller
    present(activityViewController, animated: true, completion: nil)
    }
    }
