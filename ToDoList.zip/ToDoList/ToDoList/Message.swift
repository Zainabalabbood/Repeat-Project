//
//  Message.swift
//  ToDoList
//
//  Created by BP-36-213-09 on 06/02/2025.
//

import UIKit

class Message: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    let tableView = UITableView()
    var messages: [String] = [] // Replace with your message model
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        setupNavigationBar()
    }
    
    func setupTableView() {
        tableView.frame = view.bounds
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "MessageCell")
        view.addSubview(tableView)
    }
    
    func setupNavigationBar() {
        title = "New Message"
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Send", style: .plain, target: self, action: #selector(sendMessage))
    }
    
    @objc func sendMessage() {
        // Logic to send message
        let newMessage = "Hello, World!" // Replace with actual message input
        messages.append(newMessage)
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MessageCell", for: indexPath)
        cell.textLabel?.text = messages[indexPath.row]
        return cell
    }
}
