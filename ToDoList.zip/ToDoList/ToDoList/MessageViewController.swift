//
//  MessageViewController.swift
//  ToDoList
//
//  Created by BP-36-213-09 on 06/02/2025.
//

import UIKit
import MessageUI

class MessageViewController: UIViewController, MFMailComposeViewControllerDelegate {
    
    var todo: ToDo?
    
    private let titleLabel = UILabel()
    private let detailsTextView = UITextView()
    private let sendButton = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupViews()
        populateData()
    }
    
    private func setupViews() {
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        detailsTextView.translatesAutoresizingMaskIntoConstraints = false
        sendButton.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(titleLabel)
        view.addSubview(detailsTextView)
        view.addSubview(sendButton)
        
        sendButton.setTitle("Send Message", for: .normal)
        sendButton.setTitleColor(.blue, for: .normal)
        sendButton.addTarget(self, action: #selector(sendMessage), for: .touchUpInside)

        // Layout constraints
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),

            detailsTextView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 20),
            detailsTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            detailsTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            detailsTextView.heightAnchor.constraint(equalToConstant: 200),

            sendButton.topAnchor.constraint(equalTo: detailsTextView.bottomAnchor, constant: 20),
            sendButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        ])
    }
    
    private func populateData() {
        guard let todo = todo else { return }
        titleLabel.text = todo.title
        detailsTextView.text = todo.notes ?? "No additional notes."
    }
    
    @objc private func sendMessage() {
        guard let todo = todo else { return }
        
        if MFMailComposeViewController.canSendMail() {
            let mailComposeVC = MFMailComposeViewController()
            mailComposeVC.mailComposeDelegate = self
            mailComposeVC.setSubject(todo.title)
            mailComposeVC.setMessageBody(todo.notes ?? "No additional notes.", isHTML: false)
            present(mailComposeVC, animated: true, completion: nil)
        } else {
            let alert = UIAlertController(title: "Error", message: "Email is not configured. Please set up an email account.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true)
        }
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
}
