//
//  mail.swift
//  ToDoList
//
//  Created by BP-36-213-09 on 06/02/2025.
//

import UIKit
import MessageUI

class mail: UIViewController, MFMailComposeViewControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Create and configure the button
        let sendEmailButton = UIButton(type: .system)
        sendEmailButton.setTitle("Send Email", for: .normal)
        sendEmailButton.addTarget(self, action: #selector(sendEmail), for: .touchUpInside)
        
        // Set button frame and add to the view
        sendEmailButton.frame = CGRect(x: 100, y: 200, width: 200, height: 50)
        self.view.addSubview(sendEmailButton)
    }
    
    @objc func sendEmail() {
        if MFMailComposeViewController.canSendMail() {
            let mailComposeVC = MFMailComposeViewController()
            mailComposeVC.setToRecipients(["example@gmail.com"])
            mailComposeVC.setSubject("Subject")
            mailComposeVC.setMessageBody("Sent from my iPhone", isHTML: false)
            mailComposeVC.mailComposeDelegate = self
            
            present(mailComposeVC, animated: true, completion: nil)
        } else {
            print("Mail services are not available")
        }
    }
    
    // Delegate method to handle the mail compose result
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
}
