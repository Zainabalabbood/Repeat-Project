//
//  Email.swift
//  ToDoList
//
//  Created by BP-36-213-09 on 06/02/2025.
//

import Foundation

struct Email {
    let recipient: String
    let subject: String
    let body: String
}
