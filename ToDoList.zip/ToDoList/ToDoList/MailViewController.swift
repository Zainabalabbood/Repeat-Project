//
//  MailViewController.swift
//  ToDoList
//
//  Created by BP-36-213-09 on 06/02/2025.
//

import UIKit
import MessageUI

class MailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MFMailComposeViewControllerDelegate {

    var emails: [Email] = []
    var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Mail"
        view.backgroundColor = .white
        
        setupTableView()
        setupComposeButton()
        loadEmails()
    }

    func setupTableView() {
        tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "EmailCell")
        
        view.addSubview(tableView)
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
    }

    func setupComposeButton() {
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .compose, target: self, action: #selector(composeEmail))
    }

    func loadEmails() {
        // Sample data
        emails.append(Email(recipient: "user1@example.com", subject: "Hello!", body: "This is a test email."))
        emails.append(Email(recipient: "user2@example.com", subject: "Greetings", body: "How are you?"))
        tableView.reloadData()
    }

    // MARK: - TableView DataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return emails.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EmailCell", for: indexPath)
        let email = emails[indexPath.row]
        cell.textLabel?.text = email.subject
        return cell
    }

    // MARK: - Compose Email
    @objc func composeEmail() {
        if MFMailComposeViewController.canSendMail() {
            let mailComposer = MFMailComposeViewController()
            mailComposer.setToRecipients(["recipient@example.com"])
            mailComposer.setSubject("Subject")
            mailComposer.setMessageBody("Email Body", isHTML: false)
            mailComposer.mailComposeDelegate = self
            
            present(mailComposer, animated: true, completion: nil)
        } else {
            // Handle the error
            print("Mail services are not available.")
        }
    }

    // MARK: - Mail Composer Delegate
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
}
