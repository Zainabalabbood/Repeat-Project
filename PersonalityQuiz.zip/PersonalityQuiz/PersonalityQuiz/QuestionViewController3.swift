//
//  QuestionViewController3.swift
//  PersonalityQuiz
//
//  Created by BP-36-213-09 on 05/02/2025.
//

import UIKit

class QuestionViewController3: UIViewController {
    
    @IBOutlet var questionLabel3: UILabel!
    
    @IBOutlet var singleStackView3: UIStackView!
    @IBOutlet var singleButton7: UIButton!
    @IBOutlet var singleButton8: UIButton!
    @IBOutlet var singleButton9: UIButton!
    @IBOutlet var singleButton10: UIButton!
    
    @IBOutlet var multipleStackView3: UIStackView!
    @IBOutlet var multiLabel13: UILabel!
    @IBOutlet var multiLabel14: UILabel!
    @IBOutlet var multiLabel15: UILabel!
    @IBOutlet var multiLabel16: UILabel!
    @IBOutlet var multiLabel17: UILabel!
    @IBOutlet var multiLabel18: UILabel!
    @IBOutlet var multiSwitch13: UISwitch!
    @IBOutlet var multiSwitch14: UISwitch!
    @IBOutlet var multiSwitch15: UISwitch!
    @IBOutlet var multiSwitch16: UISwitch!
    @IBOutlet var multiSwitch17: UISwitch!
    @IBOutlet var multiSwitch18: UISwitch!
    
    @IBOutlet var rangedStackView3: UIStackView!
    @IBOutlet var rangedLabel5: UILabel!
    @IBOutlet var rangedLabel6: UILabel!
    @IBOutlet var rangedSlider3: UISlider!
    
    @IBOutlet var questionProgressView3: UIProgressView!
    
    var questions3: [Question] = [
        
        Question(text: "Is it possible to keep this animal as a pet?",
                 type: .ranged,
                 answers: [
                    Answer(text: "Yes", type: .Horse),
                    Answer(text: "Yes", type: .Fox),
                    Answer(text: "Yes", type: .Panda),
                    Answer(text: "No", type: .Chick)
            ]),
        
        Question(text: "Where does the animal move?",
                 type: .single,
                 answers: [
                    Answer(text: "Pecking at the ground", type: .Chick),
                    Answer(text: "Jump and run quickly", type: .Fox),
                    Answer(text: "Trotting", type: .Horse),
                    Answer(text: "Climb", type: .Panda)
            ]),
        
        
        Question(text: "What is the color of the animal?",
                 type: .multiple,
                 answers: [
                    Answer(text: "White", type: .Panda),
                    Answer(text: "black", type: .Panda),
                    Answer(text: "Yellow", type: .Chick),
                    Answer(text: "Orange", type: .Fox),
                    Answer(text: "Grey", type: .Fox),
                    Answer(text: "White", type: .Horse)
            ])
        

    ]
    
    var questionIndex3 = 0
    var answersChosen3: [Answer] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI3()
    }
    
    @IBAction func singleAnswerButtonPressed3(_ sender: UIButton) {
        let currentAnswers3 = questions3[questionIndex3].answers

        switch sender {
        case singleButton7:
            answersChosen3.append(currentAnswers3[0])
        case singleButton8:
            answersChosen3.append(currentAnswers3[1])
        case singleButton9:
            answersChosen3.append(currentAnswers3[2])
        case singleButton10:
            answersChosen3.append(currentAnswers3[3])
        default:
            break
        }

        nextQuestion()
    }
    
    @IBAction func multipleAnswerButtonPressed3() {
        let currentAnswers3 = questions3[questionIndex3].answers

        if multiSwitch13.isOn {
            answersChosen3.append(currentAnswers3[0])
        }
        if multiSwitch14.isOn {
            answersChosen3.append(currentAnswers3[1])
        }
        if multiSwitch15.isOn {
            answersChosen3.append(currentAnswers3[2])
        }
        if multiSwitch16.isOn {
            answersChosen3.append(currentAnswers3[3])
        }
        
        if multiSwitch17.isOn {
            answersChosen3.append(currentAnswers3[2])
        }
        if multiSwitch18.isOn {
            answersChosen3.append(currentAnswers3[3])
        }

        nextQuestion()
    }
    
    @IBAction func rangedAnswerButtonPressed3() {
        let currentAnswers3 = questions3[questionIndex3].answers
        let index3 = Int(round(rangedSlider3.value * Float(currentAnswers3.count - 1)))

        answersChosen3.append(currentAnswers3[index3])

        nextQuestion()
    }
    
    
    func updateUI3() {
        singleStackView3.isHidden = true
        multipleStackView3.isHidden = true
        rangedStackView3.isHidden = true

        let currentQuestion3 = questions3[questionIndex3]
        let currentAnswers3 = currentQuestion3.answers
        let totalProgress3 = Float(questionIndex3) / Float(questions3.count)

        navigationItem.title = "Question #\(questionIndex3+1)"
        questionLabel3.text = currentQuestion3.text
        questionProgressView3.setProgress(totalProgress3, animated: true)

        switch currentQuestion3.type {
        case .single:
            updateSingleStack3(using: currentAnswers3)
        case .multiple:
            updateMultipleStack3(using: currentAnswers3)
        case .ranged:
            updateRangedStack3(using: currentAnswers3)
        }
    }
    
    func nextQuestion() {
        questionIndex3 += 1

        if questionIndex3 < questions3.count {
            updateUI3()
        } else {
            performSegue(withIdentifier: "Results", sender: nil)
        }
    }
    
    @IBSegueAction func showResults3(_ coder: NSCoder) -> ResultsViewController? {
        return ResultsViewController(coder: coder, responses: answersChosen3)
    }
    
    func updateSingleStack3(using answers: [Answer]) {
        singleStackView3.isHidden = false
        singleButton7.setTitle(answers[0].text, for: .normal)
        singleButton8.setTitle(answers[1].text, for: .normal)
        singleButton9.setTitle(answers[2].text, for: .normal)
        singleButton10.setTitle(answers[3].text, for: .normal)
    }
    
    func updateMultipleStack3(using answers: [Answer]) {
        multipleStackView3.isHidden = false
        multiSwitch13.isOn = false
        multiSwitch14.isOn = false
        multiSwitch15.isOn = false
        multiSwitch16.isOn = false
        multiSwitch17.isOn = false
        multiSwitch18.isOn = false
        multiLabel13.text = answers[0].text
        multiLabel14.text = answers[1].text
        multiLabel15.text = answers[2].text
        multiLabel16.text = answers[3].text
        multiLabel17.text = answers[4].text
        multiLabel18.text = answers[5].text
    }
    
    func updateRangedStack3(using answers: [Answer]) {
        rangedStackView3.isHidden = false
        rangedSlider3.setValue(0.5, animated: false)
        rangedLabel5.text = answers.first?.text
        rangedLabel6.text = answers.last?.text
    }
}
