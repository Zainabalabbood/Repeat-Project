import Foundation

struct Question {
    var text: String
    var type: ResponseType
    var answers: [Answer]
}

enum ResponseType {
    case single, multiple, ranged
}

struct Answer {
    var text: String
    var type: AnimalType
}

enum AnimalType: Character {
    case Panda = "🐼", Chick = "🐤", Horse = "🐴", Fox = "🦊" 
    
    var definition: String {
        switch self {
        case .Panda:
            return "You are incredibly outgoing, enjoying the company of your fellow pandas. You thrive in your lush bamboo forest, playing and interacting with your friends as you share joyful moments together."
        case .Chick:
            return "You love everything that's soft, from the cozy bedding in your coop to the gentle feathers of your friends. You are healthy and full of energy, always eager to explore and play."
        case .Horse:
            return  "Mischievous, yet mild-tempered, you enjoy galloping freely across the fields, choosing your own path and relishing the freedom of the open land."
        case .Fox:
            return "You are wise beyond your years, cunningly navigating your environment with sharp instincts. You focus on the details, knowing that a slow and steady approach will help you outsmart any challenge that comes your way."
        }
    }
}
