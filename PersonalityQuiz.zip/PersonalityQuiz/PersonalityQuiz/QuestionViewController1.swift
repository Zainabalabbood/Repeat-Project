//
//  QuestionViewController1.swift
//  PersonalityQuiz
//
//  Created by BP-36-213-09 on 02/02/2025.
//

import UIKit

class QuestionViewController1: UIViewController {
    
    @IBOutlet var questionLabel2: UILabel!
    
    @IBOutlet var singleStackView2: UIStackView!
    @IBOutlet var singleButton5: UIButton!
    @IBOutlet var singleButton6: UIButton!
    @IBOutlet var singleButton7: UIButton!
    @IBOutlet var singleButton8: UIButton!
    @IBOutlet var singleButton9: UIButton!
    @IBOutlet var singleButton10: UIButton!
    @IBOutlet var singleButton11: UIButton!
    @IBOutlet var singleButton12: UIButton!
    
    @IBOutlet var multipleStackView2: UIStackView!
    @IBOutlet var multiLabel5: UILabel!
    @IBOutlet var multiLabel6: UILabel!
    @IBOutlet var multiLabel7: UILabel!
    @IBOutlet var multiLabel8: UILabel!
    @IBOutlet var multiLabel9: UILabel!
    @IBOutlet var multiLabel10: UILabel!
    @IBOutlet var multiLabel11: UILabel!
    @IBOutlet var multiLabel12: UILabel!
    
    @IBOutlet var multiSwitch5: UISwitch!
    @IBOutlet var multiSwitch6: UISwitch!
    @IBOutlet var multiSwitch7: UISwitch!
    @IBOutlet var multiSwitch8: UISwitch!
    @IBOutlet var multiSwitch9: UISwitch!
    @IBOutlet var multiSwitch10: UISwitch!
    @IBOutlet var multiSwitch11: UISwitch!
    @IBOutlet var multiSwitch12: UISwitch!
    
    @IBOutlet var rangedStackView2: UIStackView!
    @IBOutlet var rangedLabel3: UILabel!
    @IBOutlet var rangedLabel4: UILabel!
    @IBOutlet var rangedSlider2: UISlider!
    
    @IBOutlet var questionProgressView2: UIProgressView!
    
    
    var questions2: [Question] = [
        
        Question(text: "What sound does the animal make?",
                 type: .single,
                 answers: [
                    Answer(text: "Yes", type: .Panda),
                    Answer(text: "No", type: .Fox),
                    Answer(text: "Yes", type: .Chick),
                    Answer(text: "Yes", type: .Horse)
                 ]),
        
        
        Question(text: "Is the animal typically kept as a pet?",
                 type: .multiple,
                 answers: [
                    Answer(text: "Bleat", type: .Panda),
                    Answer(text: "Cheep", type: .Chick),
                    Answer(text: "Yip", type: .Fox),
                    Answer(text: "Neigh", type: .Horse),
                    Answer(text: "whinny", type: .Horse),
                    Answer(text: "howl", type: .Fox),
                    Answer(text: "chirp", type: .Chick),
                    Answer(text: "honk", type: .Panda)
                    
                 ]),
        
        
        Question(text: "How many hour it sleep?",
                 type: .ranged,
                 answers: [
                    Answer(text: "4 hour", type: .Horse),
                    Answer(text: "8 hour", type: .Fox),
                    Answer(text: "10 hour", type: .Panda),
                    Answer(text: "12 hour", type: .Chick)
                 ])
        
    ]
    
    var questionIndex2 = 0
    var answersChosen2: [Answer] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI2()
    }
    
    
    @IBAction func singleAnswerButtonPressed2(_ sender: UIButton) {
        let currentAnswers = questions2[questionIndex2].answers
        
        switch sender {
        case singleButton5:
            answersChosen2.append(currentAnswers[0])
        case singleButton6:
            answersChosen2.append(currentAnswers[1])
        case singleButton7:
            answersChosen2.append(currentAnswers[2])
        case singleButton8:
            answersChosen2.append(currentAnswers[3])
        case singleButton9:
            answersChosen2.append(currentAnswers[4])
        case singleButton10:
            answersChosen2.append(currentAnswers[5])
        case singleButton11:
            answersChosen2.append(currentAnswers[6])
        case singleButton12:
            answersChosen2.append(currentAnswers[7])
        default:
            break
        }
        
        nextQuestion2()
    }
    
    
    @IBAction func multipleAnswerButtonPressed2() {
        let currentAnswers2 = questions2[questionIndex2].answers
        
        if multiSwitch5.isOn {
            answersChosen2.append(currentAnswers2[0])
        }
        if multiSwitch6.isOn {
            answersChosen2.append(currentAnswers2[1])
        }
        if multiSwitch7.isOn {
            answersChosen2.append(currentAnswers2[2])
        }
        if multiSwitch8.isOn {
            answersChosen2.append(currentAnswers2[3])
        }
        if multiSwitch9.isOn {
            answersChosen2.append(currentAnswers2[4])
        }
        if multiSwitch10.isOn {
            answersChosen2.append(currentAnswers2[5])
        }
        if multiSwitch11.isOn {
            answersChosen2.append(currentAnswers2[6])
        }
        if multiSwitch12.isOn {
            answersChosen2.append(currentAnswers2[7])
        }
        
        nextQuestion2()
    }
    
    @IBAction func rangedAnswerButtonPressed2() {
        let currentAnswers2 = questions2[questionIndex2].answers
        let index = Int(round(rangedSlider2.value * Float(currentAnswers2.count - 1)))
        
        answersChosen2.append(currentAnswers2[index])
        
        nextQuestion2()
    }
    
    
    func updateUI2() {
        singleStackView2.isHidden = true
        multipleStackView2.isHidden = true
        rangedStackView2.isHidden = true
        
        let currentQuestion2 = questions2[questionIndex2]
        let currentAnswers2 = currentQuestion2.answers
        let totalProgress2 = Float(questionIndex2) / Float(questions2.count)
        
        navigationItem.title = "Question #\(questionIndex2+2)"
        questionLabel2.text = currentQuestion2.text
        questionProgressView2.setProgress(totalProgress2, animated: true)
        
        switch currentQuestion2.type {
        case .single:
            updateSingleStack2(using: currentAnswers2)
        case .multiple:
            updateMultipleStack2(using: currentAnswers2)
        case .ranged:
            updateRangedStack2(using: currentAnswers2)
            
            
        }
    }
    
    func nextQuestion2() {
        questionIndex2 += 1
        
        if questionIndex2 < questions2.count {
            updateUI2()
        } else {
            performSegue(withIdentifier: "Results", sender: nil)
        }
    }
    
    @IBSegueAction func showResults2(_ coder: NSCoder) -> ResultsViewController? {
        return ResultsViewController(coder: coder, responses: answersChosen2)
    }
    
    func updateSingleStack2(using answers: [Answer]) {
        
        singleButton5.setTitle(answers[4].text, for: .normal)
        singleButton6.setTitle(answers[5].text, for: .normal)
        singleButton7.setTitle(answers[6].text, for: .normal)
        singleButton8.setTitle(answers[7].text, for: .normal)
        singleButton9.setTitle(answers[8].text, for: .normal)
        singleButton10.setTitle(answers[9].text, for: .normal)
        singleButton11.setTitle(answers[10].text, for: .normal)
        singleButton12.setTitle(answers[11].text, for: .normal)
    }
    
    func updateMultipleStack2(using answers: [Answer]) {
        
        multipleStackView2.isHidden = false
        multiSwitch5.isOn = false
        multiSwitch6.isOn = false
        multiSwitch7.isOn = false
        multiSwitch8.isOn = false
        multiSwitch9.isOn = false
        multiSwitch10.isOn = false
        multiSwitch11.isOn = false
        multiSwitch12.isOn = false
        
        multiLabel5.text = answers[4].text
        multiLabel6.text = answers[5].text
        multiLabel7.text = answers[6].text
        multiLabel8.text = answers[7].text
        multiLabel9.text = answers[8].text
        multiLabel10.text = answers[9].text
        multiLabel11.text = answers[10].text
        multiLabel12.text = answers[11].text
    }
    
    func updateRangedStack2(using answers: [Answer]) {
        rangedStackView2.isHidden = false
        rangedSlider2.setValue(0.5, animated: false)
        rangedLabel3.text = answers.first?.text
        rangedLabel4.text = answers.last?.text
        
    }
    
}
